package com.henzo.fielddatacaptureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UserWallet extends AppCompatActivity {

    Button btnDeposit, btnBackUserWallet;
    TextView textUserWalletNin;
    TextView textUserWalletId;
    TextView textWalletAmount;
    EditText textAmount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_wallet);

        textUserWalletNin = findViewById(R.id.textUserWalletNin);
        textUserWalletId = findViewById(R.id.textUserWalletId);
        textWalletAmount = findViewById(R.id.textWalletAmount);
        textAmount = findViewById(R.id.textAmountToDeposit);
        btnDeposit = findViewById(R.id.btnDeposit);
        btnBackUserWallet = findViewById(R.id.btnBackUserWallet);

        String nin;
        Bundle extras = getIntent().getExtras();
        if(extras !=null){
            nin = extras.getString("key");
            textUserWalletNin.setText(nin);
        }
        nin = textUserWalletNin.getText().toString();
        UserWalletBean ubean = new UserWalletBean();
        UserWalletDAO udao = new UserWalletDAO();
        ubean = udao.getUserWallet(nin);
        textUserWalletId.setText(ubean.getUserWalletId());
        double walletAmount = ubean.getWalletAmount();
        textWalletAmount.setText(Double.toString(walletAmount));

        UserWalletBean finalUbean = ubean;
        btnDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double amount = Double.parseDouble(textAmount.getText().toString());
                finalUbean.setWalletAmount(walletAmount+amount);
                udao.updateUserWallet(finalUbean);
                textWalletAmount.setText(Double.toString(finalUbean.getWalletAmount()));
            }
        });

        btnBackUserWallet.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
               Intent intent = new Intent(UserWallet.this, UserLogin.class);
               startActivity(intent);
            }
        });
    }
}