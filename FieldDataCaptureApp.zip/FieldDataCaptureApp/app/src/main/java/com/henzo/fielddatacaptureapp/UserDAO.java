package com.henzo.fielddatacaptureapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDAO {
    JConnect jc = new JConnect();

    public int addUser(UserBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "INSERT into users values (?, ?, ?, ?, ?, ?, ?)";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getNin());
            ps.setString(2, bean.getFirstName());
            ps.setString(3, bean.getMiddleName());
            ps.setString(4, bean.getLastName());
            ps.setString(5, bean.getPhoneNumber());
            ps.setString(6, bean.getUserPassword());
            ps.setString(7, bean.getDateOfBirth());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
                Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int updateUser(UserBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "UPDATE users SET first_name = ?, middle_name = ?, last_name = ?, phone_number = ?, u_password = ?, date_of_birth = ? where nin = ?";

        connect = jc.getNewConnection();

        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getFirstName());
            ps.setString(2, bean.getMiddleName());
            ps.setString(3, bean.getLastName());
            ps.setString(4, bean.getPhoneNumber());
            ps.setString(5, bean.getUserPassword());
            ps.setString(6, bean.getDateOfBirth());
            ps.setString(7, bean.getNin());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int deleteUser(String nin) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "DELETE from users where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public UserBean getUser(String nin) {

        UserBean bean = new UserBean();

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from users where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            rs = ps.executeQuery();
            if (rs.next()) {
                bean.setNin(rs.getString("nin"));
                bean.setFirstName(rs.getString("first_name"));
                bean.setMiddleName(rs.getString("middle_name"));
                bean.setLastName(rs.getString("last_name"));
                bean.setPhoneNumber(rs.getString("phone_number"));
                bean.setUserPassword(rs.getString("u_password"));
                bean.setDateOfBirth(rs.getString("date_of_birth"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bean;
    }

    public List<UserBean> getUsers() {

        List<UserBean> users = new ArrayList<>();

        Statement stmt = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from users";

        connect = jc.getNewConnection();
        try {
            stmt = connect.createStatement();

            rs = stmt.executeQuery(query);
            while (rs.next()) {

                UserBean bean = new UserBean();

                bean.setNin(rs.getString("nin"));
                bean.setFirstName(rs.getString("first_name"));
                bean.setMiddleName(rs.getString("middle_name"));
                bean.setLastName(rs.getString("last_name"));
                bean.setPhoneNumber(rs.getString("phone_number"));
                bean.setUserPassword(rs.getString("u_password"));
                bean.setDateOfBirth(rs.getString("date_of_birth"));

                users.add(bean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return users;
    }

    public static void main(String[] args) {
        UserDAO udao = new UserDAO();
        UserBean bean = new UserBean();

//        bean.setNin("55332233441");
//        bean.setFirstName("Henzo");
//        bean.setMiddleName("Henry");
//        bean.setLastName("Okonkwo");
//        bean.setPhoneNumber("09020867386");
//        bean.setUserPassword("bestest12");
//        bean.setDateOfBirth("2021-07-29");

//        int status = udao.addUser(bean);
//        System.out.println("Status: "+status);

//        bean.setNin("12345678909");
//        bean.setFirstName("Peter");
//        bean.setMiddleName("Chuchu");
//        bean.setLastName("Okoye");
//        bean.setPhoneNumber("09020867386");
//        bean.setUserPassword("greatest12");
//        bean.setDateOfBirth("2021-07-29");
//
//        int status = udao.updateUser(bean);
//        System.out.println("Status: "+status);

//        int status = udao.deleteUser("55332233441");
//        System.out.println("Status: "+status);

//        bean = udao.getUser("12345678909");
//        if (bean != null) {
//
//            System.out.println("NIN: " + bean.getNin());
//            System.out.println("First Name: " + bean.getFirstName());
//            System.out.println("Middle Name: " + bean.getMiddleName());
//            System.out.println("Last Name: " + bean.getLastName());
//            System.out.println("Phone Number: " + bean.getPhoneNumber());
//            System.out.println("Password: " + bean.getUserPassword());
//            System.out.println("Date of birth: " + bean.getDateOfBirth());
//        }

        List<UserBean> users = udao.getUsers();
        for (UserBean user:
             users) {
            System.out.println("");
            System.out.println("NIN: " + user.getNin());
            System.out.println("First Name: " + user.getFirstName());
            System.out.println("Middle Name: " + user.getMiddleName());
            System.out.println("Last Name: " + user.getLastName());
            System.out.println("Phone Number: " + user.getPhoneNumber());
            System.out.println("Password: " + user.getUserPassword());
            System.out.println("Date of birth: " + user.getDateOfBirth());

        }

    }
}
