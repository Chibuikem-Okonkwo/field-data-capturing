package com.henzo.fielddatacaptureapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VerifiedUserDAO {

    JConnect jc = new JConnect();

    public int addVerifiedUser(VerifiedUserBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "INSERT into verified_users values (?, ?)";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getNin());
            ps.setString(2, bean.getUserStatus());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VerifiedUserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int updateVerifiedUser(VerifiedUserBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "UPDATE verified_users SET user_status = ? where nin = ?";

        connect = jc.getNewConnection();

        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getUserStatus());
            ps.setString(2, bean.getNin());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VerifiedUserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int deleteVerifiedUser(String nin) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "DELETE from verified_users where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VerifiedUserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public VerifiedUserBean getVerifiedUser(String nin) {

        VerifiedUserBean bean = new VerifiedUserBean();

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from verified_users where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            rs = ps.executeQuery();
            if (rs.next()) {
                bean.setNin(rs.getString("nin"));
                bean.setUserStatus(rs.getString("user_status"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(VerifiedUserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bean;
    }

    public List<VerifiedUserBean> getVerifiedUsers() {

        List<VerifiedUserBean> verifiedUsers = new ArrayList<>();

        Statement stmt = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from verified_users";

        connect = jc.getNewConnection();
        try {
            stmt = connect.createStatement();

            rs = stmt.executeQuery(query);
            while (rs.next()) {

                VerifiedUserBean bean = new VerifiedUserBean();

                bean.setNin(rs.getString("nin"));
                bean.setUserStatus(rs.getString("user_status"));
                verifiedUsers.add(bean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VerifiedUserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return verifiedUsers;
    }

    public static void main(String[] args) {
        VerifiedUserBean bean = new VerifiedUserBean();
        VerifiedUserDAO dao = new VerifiedUserDAO();
//
//        bean.setNin("12345678909");
//        bean.setUserStatus("Verified");
//        int status = dao.addVerifiedUser(bean);
//        System.out.println("Status: "+status);
//
//        bean.setNin("12345678909");
//        bean.setUserStatus("Unverified");
//        int status = dao.updateVerifiedUser(bean);
//        System.out.println("Status: "+status);

//        int status = dao.deleteVerifiedUser("12345678909");
//        System.out.println("Status: "+status);

        bean = dao.getVerifiedUser("12345678909");
        if(bean!=null){
            System.out.println("NIN: " + bean.getNin());
            System.out.println("User Status: " + bean.getUserStatus());
        }
        List<VerifiedUserBean> verifiedUsers = dao.getVerifiedUsers();
        for (VerifiedUserBean verifiedUser:
                verifiedUsers) {
            System.out.println("");
            System.out.println("NIN: " + verifiedUser.getNin());
            System.out.println("User Status: " + verifiedUser.getUserStatus());
        }

    }
}
