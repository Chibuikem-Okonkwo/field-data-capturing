package com.henzo.fielddatacaptureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class AdminPage extends AppCompatActivity {

    Button btnGetUserRecord, btnGetUserWallet, btnGetAllUsers, getBtnGetAllUsersWallets;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);

        btnGetUserRecord = findViewById(R.id.btnGetUserRecord);
        btnGetUserWallet = findViewById(R.id.btnGetUserWallet);
        btnGetAllUsers = findViewById(R.id.btnGetAllUsers);
        getBtnGetAllUsersWallets = findViewById(R.id.btnGetAllUserWallets);

        btnGetAllUsers.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                UserDAO dao = new UserDAO();
                List<UserBean>users = dao.getUsers();;

            }
        });
    }
}