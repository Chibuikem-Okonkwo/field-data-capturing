package com.henzo.fielddatacaptureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserLogin extends AppCompatActivity {

    Button btnLogin, btnBack;
    EditText textNin, textPassword;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        //Assign Values to each control on the layout
        btnLogin = findViewById(R.id.btnUserLogin);
        btnBack = findViewById(R.id.btnUserLoginBack);
        textNin = findViewById(R.id.textNin);
        textPassword = findViewById(R.id.editTextPassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                String nin = textNin.getText().toString();
                String password = textPassword.getText().toString();

                AdminDAO dao = new AdminDAO();
                AdminBean bean = dao.getAdmin(nin);
                if (bean != null && bean.getAdminPassword()==password){
                    Intent intent = new Intent(UserLogin.this, UserWallet.class);
                    intent.putExtra("key", nin);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(UserLogin.this, "User Does Not Exist",  Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}