package com.henzo.fielddatacaptureapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserWalletDAO {
    JConnect jc = new JConnect();

    public int addUserWallet(UserWalletBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "INSERT into user_wallets values (?, ?, ?, ?)";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setInt(1, bean.getUserWalletId());
            ps.setString(2, bean.getNin());
            ps.setDouble(3, bean.getWalletAmount());
            ps.setString(4, bean.getEntryDate());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserWalletDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int updateUserWallet(UserWalletBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "UPDATE user_wallets SET nin = ?, wallet_amount = ?, entry_date = ? where user_wallet_id = ?";

        connect = jc.getNewConnection();

        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getNin());
            ps.setDouble(2, bean.getWalletAmount());
            ps.setString(3, bean.getEntryDate());
            ps.setInt(4, bean.getUserWalletId());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserWalletDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int deleteUserWallet(int userWalletId) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "DELETE from user_wallets where user_wallet_id = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setInt(1, userWalletId);

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserWalletDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public UserWalletBean getUserWallet(String nin) {

        UserWalletBean bean = new UserWalletBean();

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from user_wallets where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            rs = ps.executeQuery();
            if (rs.next()) {
                bean.setUserWalletId(rs.getInt("user_wallet_id"));
                bean.setNin(rs.getString("nin"));
                bean.setWalletAmount(rs.getDouble("wallet_amount"));
                bean.setEntryDate(rs.getString("entry_date"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserWalletDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bean;
    }

    public List<UserWalletBean> getUserWallets() {

        List<UserWalletBean> userWallets = new ArrayList<>();

        Statement stmt = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from user_wallets";

        connect = jc.getNewConnection();
        try {
            stmt = connect.createStatement();

            rs = stmt.executeQuery(query);
            while (rs.next()) {

                UserWalletBean bean = new UserWalletBean();

                bean.setUserWalletId(rs.getInt("user_wallet_id"));
                bean.setNin(rs.getString("nin"));
                bean.setWalletAmount(rs.getDouble("wallet_amount"));
                bean.setEntryDate(rs.getString("entry_date"));
                userWallets.add(bean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserWalletDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return userWallets;
    }

    public static void main(String[] args) {
        UserWalletBean bean = new UserWalletBean();
        UserWalletDAO dao = new UserWalletDAO();

//        bean.setUserWalletId(0);
//        bean.setNin("12345678909");
//        bean.setWalletAmount(50000.00);
//        bean.setEntryDate("2021-09-11");
//        int status = dao.addUserWallet(bean);
//        System.out.println("Status: "+status);

//        bean.setUserWalletId(3);
//        bean.setNin("12345678909");
//        bean.setWalletAmount(2222.22);
//        bean.setEntryDate("2021-09-11");
//        int status = dao.updateUserWallet(bean);
//        System.out.println("Status: "+status);
//
//        int status = dao.deleteUserWallet(3);
//        System.out.println("Status: "+status);
//
        bean = dao.getUserWallet("11223344556");
        if(bean!=null){
            System.out.println("User Wallet ID: " + bean.getUserWalletId());
            System.out.println("NIN: " + bean.getNin());
            System.out.println("Wallet Amount: " + bean.getWalletAmount());
            System.out.println("Entry Date: "+ bean.getEntryDate());
        }
        List<UserWalletBean> UserWallets = dao.getUserWallets();
        for (UserWalletBean UserWallet:
                UserWallets) {
            System.out.println("");
            System.out.println("User Wallet ID: " + UserWallet.getUserWalletId());
            System.out.println("NIN: " + UserWallet.getNin());
            System.out.println("Wallet Amount: " + UserWallet.getWalletAmount());
            System.out.println("Entry Date: "+ UserWallet.getEntryDate());
        }

    }
}
