package com.henzo.fielddatacaptureapp;

public class AdminBean {
    private String nin;
    private String email;
    private String adminPassword;

    public AdminBean() {
    }

    public AdminBean(String nin, String email, String adminPassword) {
        this.nin = nin;
        this.email = email;
        this.adminPassword = adminPassword;
    }

    public String getNin() {
        return nin;
    }

    public void setNin(String nin) {
        this.nin = nin;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    @Override
    public String toString() {
        return "AdminBean{" +
                "nin='" + nin + '\'' +
                ", email='" + email + '\'' +
                ", adminPassword='" + adminPassword + '\'' +
                '}';
    }
}
