package com.henzo.fielddatacaptureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnSubmitDetails, btnLoginAsAdmin, btnLoginAsUser;
    EditText textFirstName, textMiddleName, textLastName, textNin, textPhoneNumber, textPassword, textDateOfBirth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Assign Values to each control on the layout
        btnSubmitDetails = findViewById(R.id.btnSubmitDetails);
        btnLoginAsAdmin = findViewById(R.id.btnLoginAsAdmin);
        btnLoginAsUser = findViewById(R.id.btnLoginAsUser);

        textFirstName = findViewById(R.id.textFirstName);
        textMiddleName = findViewById(R.id.textMiddleName);
        textLastName = findViewById(R.id.textLastName);
        textNin = findViewById(R.id.textUserNin);
        textPhoneNumber = findViewById(R.id.textPhoneNumber);
        textPassword = findViewById(R.id.textPassword);
        textDateOfBirth = findViewById(R.id.textDateOfBirth);

        //click listeners for each button
        btnSubmitDetails.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                String nin =  textNin.getText().toString();
                String firstName = textFirstName.getText().toString();
                String middleName = textMiddleName.getText().toString();
                String lastName = textLastName.getText().toString();
                String phoneNumber = textPhoneNumber.getText().toString();
                String userPassword = textPassword.getText().toString();
                String dateOfBirth = textDateOfBirth.getText().toString();

                UserDAO dao = new UserDAO();
                UserBean bean = new UserBean(nin, firstName, middleName, lastName, phoneNumber, userPassword, dateOfBirth);
                int status = dao.addUser(bean);

                if(status==0){
                    UserWalletBean ubean = new UserWalletBean(0, nin, 0, "");
                    UserWalletDAO udao = new UserWalletDAO();
                    udao.addUserWallet(ubean);
                    Toast.makeText(MainActivity.this, "Details submitted successfully nin: "+nin+"password: "+userPassword,  Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Make sure All details entered are correct",  Toast.LENGTH_SHORT).show();
                }
                // Instantiate the RequestQueue.
                //RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
//                String url = "https://api.myidentitypay.com/api/v2/biometrics/merchant/data/verification/nin_wo_face"+textNin.getText().toString();
//
//                JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
//                    @Override
//                    public void onResponse(JSONArray response) {
//                        String nin = "";
//                        try {
//                           JSONObject userInfo = response.getJSONObject(0);
//                           nin = userInfo.getString("www");
//                       } catch (JSONException e) {
//                           e.printStackTrace();
//                       }
//                        Toast.makeText(MainActivity.this, "NIN: "+ nin, Toast.LENGTH_SHORT).show();
//                    }
//                }, new Response.ErrorListener(){
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(MainActivity.this, "Something Wrong", Toast.LENGTH_SHORT).show();
//                    }
//                });
//
//                //To make sure only run request runs at a time
//                MySingleton.getInstance(MainActivity.this).addToRequestQueue(request);
            }
        });

       btnLoginAsAdmin.setOnClickListener(new View.OnClickListener() {

           public void onClick(View view) {
               Intent intent = new Intent(MainActivity.this, AdminLogin.class);
               startActivity(intent);
           }
       });

        btnLoginAsUser.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, UserLogin.class);
                startActivity(intent);
//                Toast toast = Toast.makeText(MainActivity.this, "You almost clicked me", Toast.LENGTH_SHORT);
//                toast.show();
            }
        });
    }
    public void resetFields(){
        textNin.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textPhoneNumber.setText("");
        textPassword.setText("");
        textDateOfBirth.setText("");
    }
}