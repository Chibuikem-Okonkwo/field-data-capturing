package com.henzo.fielddatacaptureapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AdminDAO {

    JConnect jc = new JConnect();

    public int addAdmin(AdminBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "INSERT into admins values (?, ?, ?)";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getNin());
            ps.setString(2, bean.getEmail());
            ps.setString(3, bean.getAdminPassword());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int updateAdmin(AdminBean bean) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "UPDATE admins SET email = ?, admin_password = ? where nin = ?";

        connect = jc.getNewConnection();

        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, bean.getEmail());
            ps.setString(2, bean.getAdminPassword());
            ps.setString(3, bean.getNin());

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public int deleteAdmin(String nin) {

        int status = -1;
        PreparedStatement ps = null;
        Connection connect = null;
        String query = "DELETE from admins where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            int rowAffected = ps.executeUpdate();

            if (rowAffected == 1) {
                status = 0;
            } else {
                status = 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public AdminBean getAdmin(String nin) {

        AdminBean bean = new AdminBean();

        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from admins where nin = ?";

        connect = jc.getNewConnection();
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nin);

            rs = ps.executeQuery();
            if (rs.next()) {
                bean.setNin(rs.getString("nin"));
                bean.setEmail(rs.getString("email"));
                bean.setAdminPassword(rs.getString("admin_password"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bean;
    }

    public List<AdminBean> getAdmins() {

        List<AdminBean> admins = new ArrayList<>();

        Statement stmt = null;
        ResultSet rs = null;
        Connection connect = null;
        String query = "SELECT * from admins";

        connect = jc.getNewConnection();
        try {
            stmt = connect.createStatement();

            rs = stmt.executeQuery(query);
            while (rs.next()) {

                AdminBean bean = new AdminBean();

                bean.setNin(rs.getString("nin"));
                bean.setEmail(rs.getString("email"));
                bean.setAdminPassword(rs.getString("admin_password"));
                admins.add(bean);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return admins;
    }

    public static void main(String[] args) {
        AdminBean bean = new AdminBean();
        AdminDAO dao = new AdminDAO();
//
        bean.setNin("11002299338");
        bean.setEmail("okonkwoc99@gmail.com");
        bean.setAdminPassword("greatest");
        int status = dao.addAdmin(bean);
        System.out.println("Status: "+status);

//        bean.setNin("11002299338");
//        bean.setEmail("okonkwo.chibuikem@yahoo.com");
//        bean.setAdminPassword("Bestes");
//        int status = dao.updateAdmin(bean);
//        System.out.println("Status: "+status);

//        int status = dao.deleteAdmin("12345678909");
//        System.out.println("Status: "+status);

//        bean = dao.getAdmin("11002299338");
//        if(bean!=null){
//            System.out.println("NIN: " + bean.getNin());
//            System.out.println("Email: " + bean.getEmail());
//            System.out.println("Password: "+ bean.getAdminPassword());
//        }
        List<AdminBean> admins = dao.getAdmins();
        for (AdminBean admin:
                admins) {
            System.out.println("");
            System.out.println("NIN: " + admin.getNin());
            System.out.println("Email: " + admin.getEmail());
            System.out.println("Password: "+ admin.getAdminPassword());
        }

    }
}
