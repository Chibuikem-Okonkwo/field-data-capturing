package com.henzo.fielddatacaptureapp;

public class VerifiedUserBean {
    private String nin;
    private String userStatus;

    public VerifiedUserBean() {
    }

    public VerifiedUserBean(String nin, String userStatus) {
        this.nin = nin;
        this.userStatus = userStatus;
    }

    public String getNin() {
        return nin;
    }

    public void setNin(String nin) {
        this.nin = nin;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    @Override
    public String toString() {
        return "VerifiedUserBean{" +
                "nin='" + nin + '\'' +
                ", userStatus='" + userStatus + '\'' +
                '}';
    }
}
