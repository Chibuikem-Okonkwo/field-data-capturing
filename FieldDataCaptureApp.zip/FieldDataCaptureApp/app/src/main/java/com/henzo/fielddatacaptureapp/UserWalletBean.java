package com.henzo.fielddatacaptureapp;

public class UserWalletBean {

    private int userWalletId;
    private String nin;
    private double walletAmount;
    private String entryDate;

    public UserWalletBean() {
    }

    public UserWalletBean(int userWalletId, String nin, double walletAmount, String entryDate) {
        this.userWalletId = userWalletId;
        this.nin = nin;
        this.walletAmount = walletAmount;
        this.entryDate = entryDate;
    }

    public int getUserWalletId() {
        return userWalletId;
    }

    public void setUserWalletId(int userWalletId) {
        this.userWalletId = userWalletId;
    }

    public String getNin() {
        return nin;
    }

    public void setNin(String nin) {
        this.nin = nin;
    }

    public double getWalletAmount() {
        return walletAmount;
    }

    public void setWalletAmount(double walletAmount) {
        this.walletAmount = walletAmount;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    @Override
    public String toString() {
        return "UserWalletBean{" +
                "userWalletId=" + userWalletId +
                ", nin='" + nin + '\'' +
                ", walletAmount=" + walletAmount +
                ", entryDate='" + entryDate + '\'' +
                '}';
    }
}
