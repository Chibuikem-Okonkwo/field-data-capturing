package com.henzo.fielddatacaptureapp;
public class UserBean {

    private String nin;
    private String firstName;
    private String middleName;
    private String lastName;
    private String phoneNumber;
    private String userPassword;
    private String dateOfBirth;

    public UserBean() {
    }

    public UserBean(String nin, String firstName, String middleName, String lastName, String phoneNumber, String userPassword, String dateOfBirth) {
        this.nin = nin;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.userPassword = userPassword;
        this.dateOfBirth = dateOfBirth;
    }

    public String getNin() {
        return nin;
    }

    public void setNin(String nin) {
        this.nin = nin;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public String toString() {
        return "UserBean{" +
                "nin='" + nin + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", userPassword='" + userPassword + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                '}';
    }
}
